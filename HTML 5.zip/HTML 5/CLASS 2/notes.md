## Emmets in HTML

- Emmets are powerful tools that basically boost up our HTML and CSS code.
- Emmets are a set of abbreviations that can be used to create HTML and CSS code.